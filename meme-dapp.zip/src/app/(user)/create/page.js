import CreateCoin from '@/components/CreateCoin';

const Create = () => {
  return (
    <CreateCoin />
  );
}

export default Create;