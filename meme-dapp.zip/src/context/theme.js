import { theme } from 'antd';
const customTheme = {
  token: {
    fontSize: 14,
    colorPrimary: '#86efac',
  },
  algorithm: theme.darkAlgorithm
};

export default customTheme;